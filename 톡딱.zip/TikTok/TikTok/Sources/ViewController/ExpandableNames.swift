//
//  ExpandableNames.swift
//  TikTok
//
//  Created by IJ . on 2019/12/28.
//  Copyright © 2019 김준성. All rights reserved.
//

import Foundation

struct ExpandableNames {
    var isExpanded: Bool
    let country : String
    let cities  : [String]
}
