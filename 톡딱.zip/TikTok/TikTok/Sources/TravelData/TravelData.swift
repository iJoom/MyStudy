//
//  TravelData.swift
//  TikTok
//
//  Created by IJ . on 2019/12/29.
//  Copyright © 2019 김준성. All rights reserved.
//

import Foundation

class TravelData {
    
    static var userChooseCity:String = ""
}


//let global=TravelData()
